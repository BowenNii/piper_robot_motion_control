%% 零位->目标位姿：终点IK后走关节五次路径，仅离线分析，不操作机器人
clear;clc;
script_dir=fileparts(mfilename('fullpath'));
repo=fileparts(fileparts(fileparts(fileparts(script_dir))));
addpath(fullfile(repo,'MATLAB'));setup_piper_paths;
% prepare-endpoint完成后改为run01；offline_preview是精确零位的离线示例。
run_name='offline_preview';
data_dir=fullfile(repo,'experiments','project1','2026-10-24_zero_to_pose',run_name);
urdf=fullfile(repo,'models','urdf','piper_description.urdf');
[r,summary]=analyze_ik_trajectory(fullfile(data_dir,'trajectory.csv'),urdf);
assert(r.path_mode==1,'不是终点IK后关节路径');
m=make_piper_model(urdf);T_goal=forward_poe_space(m.S_list,[.3;.3;-.3;.3;.3;.5],m.M);
[p,a]=pose_error(r.T_matlab(:,:,end),T_goal);assert(p<1e-9 && a<1e-8);
f=figure('Color','w','Name','终点IK后的关节五次轨迹','Renderer','painters','Position',[80,80,1200,850]);
if ~usejava('desktop'),f.Visible='off';end
tiledlayout(2,2);
nexttile;plot(r.t,r.q_rad*180/pi);grid on;xlabel('t / s');ylabel('q / deg');title('六轴关节角');
legend('J1','J2','J3','J4','J5','J6','Location','best');
nexttile;plot(r.t,r.dq_rad_s);hold on;yline(.02,'r:');yline(-.02,'r:');
grid on;xlabel('t / s');ylabel('dq / rad/s');title('离线速度上限0.02rad/s');
nexttile;plot(r.t,r.ddq_rad_s2);grid on;xlabel('t / s');ylabel('ddq / rad/s^2');title('离线加速度（上限0.05rad/s^2）');
nexttile;pos=reshape(r.T_matlab(1:3,4,:),3,[])';
plot3(pos(:,1),pos(:,2),pos(:,3),'b','LineWidth',1.5);hold on;
plot3(pos(1,1),pos(1,2),pos(1,3),'go');plot3(pos(end,1),pos(end,2),pos(end,3),'ro');
axis equal;grid on;xlabel('X / m');ylabel('Y / m');zlabel('Z / m');title('模型末端路径：不是笛卡尔直线，无碰撞检查');
sgtitle('目标T -> DLS终点IK -> 60秒关节五次轨迹（非逐点笛卡尔IK）');
out=fullfile(data_dir,'matlab_analysis');if ~isfolder(out),mkdir(out);end
exportgraphics(f,fullfile(out,'endpoint_plan.png'),'Resolution',150);
writetable(summary,fullfile(out,'plan_stats.csv'));
disp(T_goal);disp(r.q_rad(end,:));disp(summary);
fprintf('终点IK回代位置残差 %.9g m，姿态残差 %.9g rad\n',p,a);
if ~usejava('desktop'),close(f);end
